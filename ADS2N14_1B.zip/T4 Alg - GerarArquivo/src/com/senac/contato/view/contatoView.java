package com.senac.contato.view;

public class contatoView {

	public void imprimeContato(String nome, String endereco, String telefone, String tipo){
		
		System.out.println("Nome: "+nome+" - Endere�o: Rua " +endereco+" - Fone: " +tipo+" "+telefone);
		
	
	}
	
}
