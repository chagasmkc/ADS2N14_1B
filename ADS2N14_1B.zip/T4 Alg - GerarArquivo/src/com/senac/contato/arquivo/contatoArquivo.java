package com.senac.contato.arquivo;

public class contatoArquivo {

}
