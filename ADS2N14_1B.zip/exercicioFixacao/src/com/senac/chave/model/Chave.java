package com.senac.chave.model;

public class Chave {
	
	private int codigo;

	public Chave(int codigo) {
		this.codigo = codigo;
	
	}

	public int getCodigo() {
		return codigo;
	}
	
		

}
