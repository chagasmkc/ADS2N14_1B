package com.senac.comodo.model;

public class Comodo {
	
	private String comodo;
	private String corComodo;
	private Double tamanhoComodo;
	private String iluminacaoComodo;
	
	
	
	public String getComodo() {
		return comodo;
	}

	public String getCorComodo() {
		return corComodo;
	}
	
	public Double getTamanhoComodo() {
		return tamanhoComodo;
	}
	
	public String iluminacao() {
		return iluminacaoComodo;
	}

	public void setComodo(String comodo) {
		this.comodo = comodo;
	}

	public void setCorComodo(String corComodo) {
		this.corComodo = corComodo;
	}

	public void setTamanhoComodo(Double tamanhoComodo) {
		this.tamanhoComodo = tamanhoComodo;
	}
	
	public void setIluminacao(String iluminacaoComodo) {
		this.iluminacaoComodo = iluminacaoComodo;
	}

}

