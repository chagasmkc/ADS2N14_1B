package com.senac.pessoa.view;


public class PessoaView {

	/**
	 * @param args
	 */
	public void imprimeCliente(String nome, String endereco, String telefone, String tipo){
			
		System.out.println("Nome: "+nome+" - Endere�o: Rua " +endereco+" - Fone: " +tipo+" "+telefone);
		
	
	}

}
